


<?php $__env->startSection('content'); ?>

<article>
    <h2> <?php echo e($new_berita["judul"]); ?> </h2>
    <h3> <?php echo e($new_berita["penulis"]); ?></h3>
    <p> <?php echo e($new_berita["isi"]); ?></p>
</article>


<a href="/berita">kembali</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\laravel\resources\views/singleberita.blade.php ENDPATH**/ ?>