    
<?php $__env->startSection('content'); ?>

<h1>HELLO</h1>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\laravel\resources\views/home.blade.php ENDPATH**/ ?>