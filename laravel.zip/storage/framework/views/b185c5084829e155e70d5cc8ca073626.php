    
<?php $__env->startSection('content'); ?>

<h1 class="text-center">Tambah Data Mahasiswa</h1>
<div class="col-8">
<div class="card ">
    <div class="card-body">
<form action="/insertdata" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
  <div class="mb-3">
    <label for="nama" class="form-label">Nama</label>
    <input type="text" name="name" placeholder="Nama Lengkap" class="form-control" id="nama" >
  </div>
  <div class="mb-3">
    <label for="nim" class="form-label">Nomor Induk Mahasiswa</label>
    <input type="number" name="nim" class="form-control" id="nim" >
  </div>
  <div class="mb-3">
    <label for="prodi" class="form-label">Program Studi</label>
    <input type="text" name="prodi" class="form-control" id="prodi" >
  </div>
  <div class="mb-3">
    <label for="email" class="form-label">Email</label>
    <input type="email" name="email" class="form-control" id="email" >
  </div>
    <div class="mb-3">
        <label for="nohp" class="form-label">Nomor Handphone</label>
        <input type="number" name="nohp" class="form-control" id="nohp" >
  <!-- <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Password</label>
    <input type="password" class="form-control" id="exampleInputPassword1">
  </div> -->
  <div class="mb-3 form-check">
    <input type="checkbox" class="form-check-input" id="exampleCheck1">
    <label class="form-check-label" for="exampleCheck1">Check me out</label>
  </div>
  <button type="submit" class="btn btn-primary">Submit</button>
</form> 
</div>
</div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\laravel\resources\views/tambahmahasiswa.blade.php ENDPATH**/ ?>