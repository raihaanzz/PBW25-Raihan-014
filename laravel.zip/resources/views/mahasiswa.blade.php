@extends('layouts.main')

@section('content')
<h1 class=text-center>Data Mahasiswa</h1>
<div class="row mt-4">
    <a href="/tambahmahasiswa">
    <button type="button" class="btn btn-success mb-2">Tambah Data</button></a>
    @if ($message = Session::get('success'))
    <div class="alert alert-success" role="alert">
        {{ $message }}
    </div>
    @endif

    <table class="table">
  <thead>
    <tr>
      <th scope="col">No</th>
      <th scope="col">Nama</th>
      <th scope="col">NIM</th>
      <th scope="col">Prodi</th>
      <th scope="col">Email</th>
      <th scope="col">No. Hp</th>
      <th scope="col">Aksi</th>
    </tr>
  </thead>
  <tbody>
    <?php $i= 1 ?>
    @foreach ($data as $mahasiswa)
    <tr>
      <th scope="row"><?php echo $i ?></th>
      <td>{{$mahasiswa["name"]}}</td>
      <td>{{$mahasiswa["nim"]}}</td>
      <td>{{$mahasiswa["prodi"]}}</td>
      <td>{{$mahasiswa["email"]}}</td>
      <td>{{$mahasiswa["nohp"]}}</td>
      <td>
        <a href="tampildata/{{ $mahasiswa['id']}}" class="btn btn-primary">Edit</a>
        <a href="delete/{{ $mahasiswa['id']}}" class="btn btn-danger" onclick="return confirm ('Yakin hapus?')">Hapus</a>
      </td>
      <?php $i++ ?>
    </tr>
    @endforeach
  </tbody>
</table>
</div>
@endsection