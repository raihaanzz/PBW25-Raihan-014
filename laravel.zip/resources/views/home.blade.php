@extends('layouts.main')    
@section('content')

<h1>HELLO</h1>


@endsection